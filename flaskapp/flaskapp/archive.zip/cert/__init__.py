import logging
logging.info('the cert/__init__.py')
